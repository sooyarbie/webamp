Kai v2
Based on a Windows VS, a work in progress by me


Brw2KX
Copyright � 2005
http://brw2k1.deviantart.com/
